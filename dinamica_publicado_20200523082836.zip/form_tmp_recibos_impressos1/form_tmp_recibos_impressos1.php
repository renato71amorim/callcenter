<?php 
  include_once('../form_tmp_recibos_impressos1/index.php'); 
?> 
