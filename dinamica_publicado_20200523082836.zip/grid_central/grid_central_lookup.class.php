<?php
class grid_central_lookup
{
}
?>
