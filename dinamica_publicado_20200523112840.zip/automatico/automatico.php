<?php 
  include_once('../automatico/index.php'); 
?> 
